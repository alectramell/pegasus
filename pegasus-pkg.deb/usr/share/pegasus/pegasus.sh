#!/bin/bash

clear

RUNAPP=$(cd /usr/share/pegasus/library/apps/ && zenity --file-selection --file-filter=*.pgs --title="Pegasus v1.0 | Activate an App..") && gnome-terminal --title="Pegasus v1.0 | App Activation.." -x sh -c "exec $RUNAPP" && zenity --info --title="Pegasus v1.0" --text="Activation Complete!"

clear
